package Asg3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class populate {
	
	Connection  connection = null; 
	populate()
	{
		
		connection =  dbconnector.getConnection();
	}
	public static void main(String[] args) throws SQLException, IOException {
		// TODO Auto-generated method stub
		populate p = new populate();
		
		p.insertMOVIES(args[0]);
		p.inserttags(args[1]);
		p.insertMOVIE_COUNTRIES(args[2]);
	  	p.insertMOVIE_GENRES(args[3]);
	
		p.insertmovie_TAGS(args[4]);
		p.insertMOVIE_LOCATION(args[5]);
		
		
		
	}
	
	public void insertMOVIES(String filepath) throws SQLException, IOException
	{
		
		PreparedStatement movies_sql = null; 
		try { 
		FileReader file = new FileReader(filepath);
		BufferedReader br = new BufferedReader(file);
		br.readLine();
		String fileData = null;
		while((fileData = br.readLine())!= null){
		String[] data = fileData.split("\t");
		Integer id = Integer.parseInt(data[0]);
		String title = data[1];	
		Integer imdbID	= Integer.parseInt(data[2]);
		String spanishTitle = data[3];	
		String imdbPictureURL	= data[4];
		Integer year = Integer.parseInt(data[5]);
		String rtID = data[6];
		String rtAllCriticsRating = data[7];
		String rtAllCriticsNumReviews = data[8];	
		String rtAllCriticsNumFresh = data[9];
		String rtAllCriticsNumRotten = data[10];	
		String rtAllCriticsScore = data[11];
		String rtTopCriticsRating = data[12];
		String rtTopCriticsNumReviews = data[13];
		String rtTopCriticsNumFresh = data[14];
		String rtTopCriticsNumRotten = data[15];
		String rtTopCriticsScore = data[16];
		String rtAudienceRating = data[17];
		String rtAudienceNumRatings = data[18];
		String rtAudienceScore	= data[19];
		String rtPictureURL = data[20];

		if(movies_sql == null){
		String sql = "INSERT INTO MOVIES VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		movies_sql = connection.prepareStatement(sql);
		}
		movies_sql.setInt(1, id);
		movies_sql.setString(2, title);
		movies_sql.setInt(3, imdbID);
		movies_sql.setString(4, spanishTitle);
		movies_sql.setString(5, imdbPictureURL);
		movies_sql.setInt(6, year);
		movies_sql.setString(7, rtID);
		if(!rtAllCriticsRating.equals("\\N")) movies_sql.setFloat(8, Float.parseFloat(rtAllCriticsRating));
		if(!rtAllCriticsNumReviews.equals("\\N"))movies_sql.setInt(9, Integer.parseInt(rtAllCriticsNumReviews));
		if(!rtAllCriticsNumFresh.equals("\\N"))movies_sql.setInt(10, Integer.parseInt(rtAllCriticsNumFresh));
		if(!rtAllCriticsNumRotten.equals("\\N"))movies_sql.setInt(11, Integer.parseInt(rtAllCriticsNumRotten));
		if(!rtAllCriticsScore.equals("\\N"))movies_sql.setInt(12, Integer.parseInt(rtAllCriticsScore));
		if(!rtTopCriticsRating.equals("\\N"))movies_sql.setFloat(13, Float.parseFloat(rtTopCriticsRating));
		if(!rtTopCriticsNumReviews.equals("\\N"))movies_sql.setInt(14, Integer.parseInt(rtTopCriticsNumReviews));
		if(!rtTopCriticsNumFresh.equals("\\N"))movies_sql.setInt(15, Integer.parseInt(rtTopCriticsNumFresh));
		if(!rtTopCriticsNumRotten.equals("\\N"))movies_sql.setInt(16, Integer.parseInt(rtTopCriticsNumRotten));
		if(!rtTopCriticsScore.equals("\\N"))movies_sql.setInt(17, Integer.parseInt(rtTopCriticsScore));
		if(!rtAudienceRating.equals("\\N"))movies_sql.setFloat(18, Float.parseFloat(rtAudienceRating));
		if(!rtAudienceNumRatings.equals("\\N"))movies_sql.setInt(19, Integer.parseInt(rtAudienceNumRatings));
		if(!rtAudienceScore.equals("\\N"))movies_sql.setInt(20, Integer.parseInt(rtAudienceScore));
		if(!rtPictureURL.equals("\\N"))movies_sql.setString(21, rtPictureURL);
		movies_sql.executeUpdate();
		
		}
		}catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();}
//			finally
//		 {
//				movies_sql.close();
//				connection.close();
//				System.out.println("movies close");
//		 }
		connection.close();
		 }
	
	public void inserttags(String filePath) throws SQLException
	
	{
		Connection  connection = null;
		connection =  dbconnector.getConnection();
		PreparedStatement movies_sql = null; 
		try {
		
		FileReader file = new FileReader(filePath);
		BufferedReader br = new BufferedReader(file);
		br.readLine();
		String fileData = null;
		while((fileData = br.readLine()) != null){
			String[] data = fileData.split("\t");
			Integer tagId 	= Integer.parseInt(data[0]);
			String value = data[1];
			if(movies_sql == null){
				String sql = "INSERT INTO TAGS VALUES(?,?)";
				movies_sql = connection.prepareStatement(sql);
			}
			movies_sql.setInt(1, tagId);
			movies_sql.setString(2, value);
			movies_sql.executeUpdate();
		}
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally
		{
		
		connection.close();
		}
}
	public void insertmovie_actors(String filePath)
	{
		 try {
			 Connection  connection = null;
				connection =  dbconnector.getConnection();	
			 PreparedStatement movies_sql = null; 
				FileReader file = new FileReader(filePath);
				BufferedReader br = new BufferedReader(file);
				br.readLine();
				String fileData = null;
				while((fileData = br.readLine()) != null){
					String[] data = fileData.split("\t");
					Integer movieID 	= Integer.parseInt(data[0]);
					String actorID = data[1];
					String actorName = data[2];
					Integer ranking = Integer.parseInt(data[3]);
					if(movies_sql == null){
						String sql = "INSERT INTO  movie_actors VALUES(?,?,?,?)";
						movies_sql = connection.prepareStatement(sql);
					}
					movies_sql.setInt(1, movieID);
					movies_sql.setString(2, actorID);
					movies_sql.setString(3, actorName);
					movies_sql.setInt(4, ranking);
					movies_sql.executeUpdate();
				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	 }
	public void insertMOVIE_COUNTRIES(String filepath) throws SQLException, IOException
	{
		
		Connection  connection = null;
		connection =  dbconnector.getConnection();
		BufferedReader br = new BufferedReader(new FileReader(filepath));
		String strline=null;
		PreparedStatement businessSQL = null;
		br.readLine();
		while((strline=br.readLine()) != null)
		{
			String lines[]= strline.split("\t");
			Integer num1;
			String num2;
			if(lines.length==2)
			{ num1 =  Integer.parseInt(lines[0]);
			 num2 =   lines[1];
			}
			else
				 {num1 =  Integer.parseInt(lines[0]);
					num2="";}	
			 if (businessSQL == null)
	            {
	                String sql = "INSERT INTO  MOVIE_COUNTRIES VALUES(?,?)";
	                businessSQL = connection.prepareStatement(sql);
	            }
			   businessSQL.setInt(1,num1);
		       businessSQL.setString(2,num2);
		       	       
		       businessSQL.executeUpdate();
			
		}
		connection.close();
	}
	public void insertMOVIE_DIRECTORS(String filepath) throws SQLException, IOException
	{
		Connection  connection = null;
		connection =  dbconnector.getConnection();
		Statement stmt = null;
        stmt = (Statement) connection.createStatement();
        BufferedReader br = new BufferedReader(new FileReader(filepath));
		String strline=null;
		PreparedStatement businessSQL = null;
		br.readLine();
		while((strline=br.readLine()) != null)
		{
			String lines[]= strline.split("\t");
			
			Integer num1 =  Integer.parseInt(lines[0]);
			String num2 =   lines[1];
			String num3 =   lines[2];
			
			
			 if (businessSQL == null)
	            {
	                String sql = "INSERT INTO MOVIE_DIRECTORS VALUES(?,?,?)";
	                businessSQL = connection.prepareStatement(sql);
	            }
			   businessSQL.setInt(1,num1);
		       businessSQL.setString(2,num2);
		       businessSQL.setString(3,num3);
		       
		       businessSQL.executeUpdate();
			
		}
	}
	public void insertMOVIE_GENRES(String filepath) throws SQLException, IOException
	{
		
		Connection  connection = null;
		connection =  dbconnector.getConnection();
		Statement stmt = null;
        stmt = (Statement) connection.createStatement();
        BufferedReader br = new BufferedReader(new FileReader(filepath));
		String strline=null;
		PreparedStatement businessSQL = null;
		br.readLine();
		while((strline=br.readLine()) != null)
		{
			String lines[]= strline.split("\t");
			
			Integer num1 =  Integer.parseInt(lines[0]);
			String num2 =   lines[1];
			
			
			
			 if (businessSQL == null)
	            {
	                String sql = "INSERT INTO MOVIE_GENRES VALUES(?,?)";
	                businessSQL = connection.prepareStatement(sql);
	            }
			   businessSQL.setInt(1,num1);
		       businessSQL.setString(2,num2);
		       
		      
		       
		       businessSQL.executeUpdate();
			
		}
		connection.close();
	}
	public void insertMOVIE_LOCATION(String filepath) throws SQLException, IOException
	{
		Connection  connection = null;
		connection =  dbconnector.getConnection();
		
		Statement stmt = null;
        stmt = (Statement) connection.createStatement();
        BufferedReader br = new BufferedReader(new FileReader(filepath));
		String strline=null;
		PreparedStatement businessSQL = null;
		br.readLine();
		while((strline=br.readLine()) != null)
		{
			String lines[]= strline.split("\t");
			Integer num1 =0;
			String num2 = "";
			num1 =  Integer.parseInt(lines[0]);
			if((lines.length==2))
			{
				num2=lines[1];
			}
			else{
				
				num2="";
			}
			
						 if (businessSQL == null)
	            {
	                String sql = "INSERT INTO MOVIE_LOCATIONS VALUES(?,?)";
	                businessSQL = connection.prepareStatement(sql);
	            }
			   businessSQL.setInt(1,num1);
		       businessSQL.setString(2,num2);
		     
		       businessSQL.executeUpdate();
			
		}
		connection.close();
			
		}
	
	public void insertmovie_TAGS(String filepath) throws SQLException, IOException
	{
		
		Connection  connection = null;
		connection =  dbconnector.getConnection();
		Statement stmt = null;
        stmt = (Statement) connection.createStatement();
        BufferedReader br = new BufferedReader(new FileReader(filepath));
		String strline=null;
		PreparedStatement businessSQL = null;
		br.readLine();
		while((strline=br.readLine()) != null)
		{
			String lines[]= strline.split("\t");
			
			Integer num1 =  Integer.parseInt(lines[0]);
			Integer num2 =  Integer.parseInt(lines[1]);
			Integer num3 =  Integer.parseInt(lines[2]);
			
			
			 if (businessSQL == null)
	            {
	                String sql = "INSERT INTO movie_TAGS VALUES(?,?,?)";
	                businessSQL = connection.prepareStatement(sql);
	            }
			   businessSQL.setInt(1,num1);
		       businessSQL.setInt(2,num2);
		       businessSQL.setInt(3,num3);
		    
		       
		       businessSQL.executeUpdate();
			
		}
		connection.close();
		
	}
	public void insertUSER_RATEDMOVIES(String filepath) throws SQLException, IOException
	{
		
		Connection  connection = null;
		connection =  dbconnector.getConnection();
		Statement stmt = null;
        stmt = (Statement) connection.createStatement();
        BufferedReader br = new BufferedReader(new FileReader(filepath));
		String strline=null;
		PreparedStatement businessSQL = null;
		br.readLine();
		while((strline=br.readLine()) != null)
		{
			String lines[]= strline.split("\t");
			
			Integer num1 =  Integer.parseInt(lines[0]);
			Integer num2 =  Integer.parseInt(lines[1]);
			Float num3 =  Float.parseFloat(lines[2]);
			Integer num4 =  Integer.parseInt(lines[3]);
			Integer num5 =  Integer.parseInt(lines[4]);
			Integer num6 =  Integer.parseInt(lines[5]);
			Integer num7 =  Integer.parseInt(lines[6]);
			Integer num8 =  Integer.parseInt(lines[7]);
			Integer num9 =  Integer.parseInt(lines[8]);
			
			
			 if (businessSQL == null)
	            {
	                String sql = "INSERT INTO USER_RATEDMOVIES VALUES(?,?,?,?,?,?,?,?,?)";
	                businessSQL = connection.prepareStatement(sql);
	            }
			   businessSQL.setInt(1,num1);
		       businessSQL.setInt(2,num2);
		       businessSQL.setFloat(3,num3);
		       businessSQL.setInt(4,num4);
		       businessSQL.setInt(5,num5);
		       businessSQL.setInt(6,num6);
		       businessSQL.setInt(7,num7);
		       businessSQL.setInt(8,num8);
		       businessSQL.setInt(9,num9);
		       
		       businessSQL.executeUpdate();
			
		}
		
	}
	public void insertuser_ratedmovies_timestamps(String filepath) throws SQLException, IOException
	{
		
		Connection  connection = null;
		connection =  dbconnector.getConnection();
		Statement stmt = null;
        stmt = (Statement) connection.createStatement();
        BufferedReader br = new BufferedReader(new FileReader(filepath));
		String strline=null;
		PreparedStatement businessSQL = null;
		br.readLine();
		while((strline=br.readLine()) != null)
		{
			String lines[]= strline.split("\t");
			
			Integer num1 =  Integer.parseInt(lines[0]);
			Integer num2 =  Integer.parseInt(lines[1]);
			Float   num3   =  Float.parseFloat(lines[2]);
			Double num4 =  Double.parseDouble(lines[3]);
			
			
			
			 if (businessSQL == null)
	            {
	                String sql = "INSERT INTO user_ratedmovies_timestamps VALUES(?,?,?,?)";
	                businessSQL = connection.prepareStatement(sql);
	            }
			   businessSQL.setInt(1,num1);
		       businessSQL.setInt(2,num2);
		       businessSQL.setFloat(3,num3);
		       businessSQL.setDouble(4,num4);
		       
		       
		       businessSQL.executeUpdate();
			
		}
		
	}
	public void insertuser_tagedmovies(String filepath) throws SQLException, IOException
	{
		
		Connection  connection = null;
		connection =  dbconnector.getConnection();
		Statement stmt = null;
        stmt = (Statement) connection.createStatement();
        BufferedReader br = new BufferedReader(new FileReader(filepath));
		String strline=null;
		PreparedStatement businessSQL = null;
		br.readLine();
		while((strline=br.readLine()) != null)
		{
			String lines[]= strline.split("\t");
			
			Integer num1 =  Integer.parseInt(lines[0]);
			Integer num2 =  Integer.parseInt(lines[1]);
			Integer num3 =  Integer.parseInt(lines[2]);
			Integer num4 =  Integer.parseInt(lines[3]);
			Integer num5 =  Integer.parseInt(lines[4]);
			Integer num6 =  Integer.parseInt(lines[5]);
			Integer num7 =  Integer.parseInt(lines[6]);
			Integer num8 =  Integer.parseInt(lines[7]);
			Integer num9 =  Integer.parseInt(lines[8]);
			
			
			 if (businessSQL == null)
	            {
	                String sql = "INSERT INTO  user_tagedmovies VALUES(?,?,?,?,?,?,?,?,?)";
	                businessSQL = connection.prepareStatement(sql);
	            }
			   businessSQL.setInt(1,num1);
		       businessSQL.setInt(2,num2);
		       businessSQL.setInt(3,num3);
		       businessSQL.setInt(4,num4);
		       businessSQL.setInt(5,num5);
		       businessSQL.setInt(6,num6);
		       businessSQL.setInt(7,num7);
		       businessSQL.setInt(8,num8);
		       businessSQL.setInt(9,num9);
		       
		       businessSQL.executeUpdate();
			
		}
	}
	
	public void insertuser_taggedmovies_timestamps(String filepath) throws SQLException, IOException
	{
		
		Connection  connection = null;
		connection =  dbconnector.getConnection();
		Statement stmt = null;
        stmt = (Statement) connection.createStatement();
        BufferedReader br = new BufferedReader(new FileReader(filepath));
		String strline=null;
		PreparedStatement businessSQL = null;
		br.readLine();
		while((strline=br.readLine()) != null)
		{
			String lines[]= strline.split("\t");
			
			Integer num1 =  Integer.parseInt(lines[0]);
			Integer num2 =  Integer.parseInt(lines[1]);
			Integer num3 =  Integer.parseInt(lines[2]);
			Double num4 =  Double.parseDouble(lines[3]);
			
			 if (businessSQL == null)
	            {
	                String sql = "INSERT INTO  user_taggedmovies_timestamps VALUES(?,?,?,?)";
	                businessSQL = connection.prepareStatement(sql);
	            }
			   businessSQL.setInt(1,num1);
		       businessSQL.setInt(2,num2);
		       businessSQL.setInt(3,num3);
		       businessSQL.setDouble(4,num4);
		       
		       businessSQL.executeUpdate();
			
		}
	}
}
