package Assignment3;

public class Display_Result {
	
	String title;
	String genre;
	int year;
	String country;
	String locations;
	String avgRTAllCriticsRating;
	String avgRTAllCriticsReviews;
	
	public Display_Result(String title , String genre , int year ,String country,String locations,String avgRTAllCriticsRating ,String avgRTAllCriticsReviews) {
		// TODO Auto-generated constructor stub
		this.title = title;
		this.genre=genre;
		this.year = year;
		this.country = country;
		this.locations = locations;
		this.avgRTAllCriticsRating = avgRTAllCriticsRating;
		this.avgRTAllCriticsReviews = avgRTAllCriticsReviews;
		
	}
	
	public String getTitle() {
		return title;
	}
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public void setAvgRTAllCriticsReviews(String avgRTAllCriticsReviews) {
		this.avgRTAllCriticsReviews = avgRTAllCriticsReviews;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getLocations() {
		return locations;
	}
	public void setLocations(String locations) {
		this.locations = locations;
	}
	public String getAvgRTAllCriticsRating() {
		return avgRTAllCriticsRating;
	}
	public void setAvgRTAllCriticsRating(String avgRTAllCriticsRating) {
		this.avgRTAllCriticsRating = avgRTAllCriticsRating;
	}
	public String getAvgRTAllCriticsReviews() {
		return avgRTAllCriticsReviews;
	}
	
	
	
}
