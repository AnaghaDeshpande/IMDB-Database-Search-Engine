package Assignment3;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import java.awt.ScrollPane;
import java.awt.TextArea;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.BoxLayout;
import javax.swing.ComboBoxEditor;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JSlider;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.DefaultComboBoxModel;

import org.jdatepicker.JDatePicker;
import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;



public class FrontEnd extends JFrame {

	private JPanel contentPane;
	private JTextField rating;
	private JTextField reviews;
	private JTextField fromyear;
	private JTextField to_year;
	private JTextField comboVal;
	JComboBox comboAndOr;
	JComboBox comboTag;
	JTextPane textPane;
	String query_display;
	JList tag_list;
	JScrollPane scrollPane;
	JPanel panel_3;
	
	
	/**
	 * Launch the application.
	 */
	
	static Hw3 hw3=null;
	
	
	
	public static void main(String[] args) {
		hw3 =new Hw3();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrontEnd frame = new FrontEnd();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		
	}

	/**
	 * Create the frame.
	 * @throws SQLException 
	 */
	public FrontEnd() throws SQLException {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1392, 724);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(31, 16, 666, 343);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_4.setBounds(15, 26, 179, 245);
		panel.add(panel_4);
		panel_4.setLayout(null);
		
		
		
		final ArrayList<String> list =  hw3.getGenres();
		String[] genre_str = (String[]) list.toArray(new String[list.size()]);
		
		JList list_genres = new JList();
		list_genres.setModel(new AbstractListModel() {
			String[] values =(String[]) list.toArray(new String[list.size()]);
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
	
		list_genres.setBounds(165, 48, -99, 206);
	
	   
		JScrollPane scp = new JScrollPane(list_genres);
		scp.setSize(170, 210);
		scp.setLocation(5, 10);
		panel_4.add(scp);
		
		
		// Countries Panel
		JPanel panel_5 = new JPanel();
		panel_5.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_5.setBounds(234, 32, 169, 239);
		panel.add(panel_5);
		panel_5.setLayout(null);
		JList list_Countries = new JList();
		JScrollPane scp1 = new JScrollPane(list_Countries);
		scp1.setSize(164, 210);
		scp1.setLocation(5, 10);
		panel_5.add(scp1);
		
		// Genre Button
		JButton genre_btn = new JButton("Next");
		genre_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				 
				List<String> values = ( ( list_genres.getSelectedValuesList()));
				
				
				String Condition = comboAndOr.getSelectedItem().toString();
				ArrayList<String> genre1 =hw3.getCountries(values ,  Condition);
				
			//	String[] genre_str = (String[]) genre1.toArray(new String[genre1.size()]);
				
				list_Countries.setModel(new AbstractListModel() {
					String[] values =(String[]) genre1.toArray(new String[genre1.size()]);
					public int getSize() {
						return values.length;
					}
					public Object getElementAt(int index) {
						return values[index];
					}
				});
			}
		});
		
		
		// Movie Locations
		
		JPanel panel_7 = new JPanel();
		
		panel_7.setBounds(459, 32, 169, 239);
		panel.add(panel_7);
		panel_7.setLayout(null);
		JList list_locations = new JList();
		JScrollPane scp2 = new JScrollPane(list_locations);
		scp2.setSize(164, 210);
		scp2.setLocation(5, 10);
		panel_7.add(scp2);
		
		
		JLabel lblGenres = new JLabel("Genres");
		lblGenres.setBounds(52, 0, 69, 20);
		panel.add(lblGenres);
		
		comboAndOr = new JComboBox();
		comboAndOr.setBounds(339, 304, 136, 26);
		panel.add(comboAndOr);
		comboAndOr.addItem("AND");
		comboAndOr.addItem("OR");
		
		JLabel Search = new JLabel("Search Between AND / OR");
		Search.setBounds(103, 307, 241, 20);
		panel.add(Search);
		
		JLabel lblNewLabel = new JLabel("Country");
		lblNewLabel.setBounds(255, 0, 69, 20);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Filming Location");
		lblNewLabel_1.setBounds(459, 0, 169, 20);
		panel.add(lblNewLabel_1);
		
		
		genre_btn.setBounds(53, 270, 115, 29);
		panel.add(genre_btn);
		
		JButton country_btn = new JButton("Next");
		country_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				// Button to fetch Location:
                 List<String> countries = ( ( list_Countries.getSelectedValuesList()));
                 List<String> genres = ( ( list_genres.getSelectedValuesList()));
				
                
				
				
				String condition = comboAndOr.getSelectedItem().toString();
                 ArrayList<String> locations =hw3.getLocations(countries,genres,condition);
				
			//	String[] genre_str = (String[]) genre1.toArray(new String[genre1.size()]);
				
				list_locations.setModel(new AbstractListModel() {
					String[] values =(String[]) locations.toArray(new String[locations.size()]);
					public int getSize() {
						return values.length;
					}
					public Object getElementAt(int index) {
						return values[index];
					}
				});
				
				
			}
		});
		country_btn.setBounds(271, 270, 115, 29);
		panel.add(country_btn);
		
		JButton btnNewButton_2 = new JButton("Next");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				List<String> values = ( ( list_locations.getSelectedValuesList()));
				String Condition = comboAndOr.getSelectedItem().toString();
				hw3.getColumnQuery(values , Condition);
			}
		});
		btnNewButton_2.setBounds(469, 270, 115, 29);
		panel.add(btnNewButton_2);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_1.setBounds(712, 16, 643, 343);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JPanel criticsRating = new JPanel();
		criticsRating.setBorder(new LineBorder(new Color(0, 0, 0)));
		criticsRating.setBounds(0, 27, 207, 237);
		panel_1.add(criticsRating);
		criticsRating.setLayout(null);
		
		JComboBox comboRating = new JComboBox();
		comboRating.setModel(new DefaultComboBoxModel(new String[] {"=", "<", ">", "<=", ">="}));
		comboRating.setBounds(147, 16, 60, 26);
		criticsRating.add(comboRating);
		comboRating.addItem("=");
		
		rating = new JTextField();
		rating.setBounds(81, 58, 126, 26);
		criticsRating.add(rating);
		rating.setColumns(10);
		
		JComboBox comboReviews = new JComboBox();
		comboReviews.setModel(new DefaultComboBoxModel(new String[] {"=", "<", ">", "<=", ">="}));
		comboReviews.setBounds(147, 110, 60, 26);
		criticsRating.add(comboReviews);
		
		reviews = new JTextField();
		reviews.setBounds(89, 168, 118, 26);
		criticsRating.add(reviews);
		reviews.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Rating");
		lblNewLabel_2.setBounds(15, 19, 69, 20);
		criticsRating.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("No. Of . reviews");
		lblNewLabel_3.setBounds(15, 113, 132, 20);
		criticsRating.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Value");
		lblNewLabel_4.setBounds(15, 61, 69, 20);
		criticsRating.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Value");
		lblNewLabel_5.setBounds(15, 171, 69, 20);
		criticsRating.add(lblNewLabel_5);
		
		JLabel lblCriticsRating = new JLabel("Critics rating");
		lblCriticsRating.setBounds(15, 0, 160, 20);
		panel_1.add(lblCriticsRating);
		
		JPanel TagValue = new JPanel();
		TagValue.setBorder(new LineBorder(new Color(0, 0, 0)));
		TagValue.setBounds(222, 27, 364, 237);
		panel_1.add(TagValue);
		TagValue.setLayout(null);
		
		JScrollPane scroll2 = new JScrollPane (JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroll2.setBounds(10, 10, 330, 200);
		TagValue.add(scroll2);
		
		
		
		
		JLabel fromYear = new JLabel("From year");
		fromYear.setBounds(10, 280, 107, 20);
		panel_1.add(fromYear);
		
		JLabel toYear = new JLabel("To year");
		toYear.setBounds(15, 316, 102, 20);
		panel_1.add(toYear);
		
		fromyear = new JTextField();
		fromyear.setBounds(132, 280, 75, 26);
		panel_1.add(fromyear);
		fromyear.setColumns(10);
		
		to_year = new JTextField();
		to_year.setBounds(132, 313, 75, 26);
		panel_1.add(to_year);
		to_year.setColumns(10);
		
		JLabel tagValue = new JLabel("Tag Weight");
		tagValue.setBounds(232, 280, 95, 20);
		panel_1.add(tagValue);
		
		JLabel lblNewLabel_6 = new JLabel("value");
		lblNewLabel_6.setBounds(242, 316, 69, 20);
		panel_1.add(lblNewLabel_6);
		
		comboTag = new JComboBox();
		comboTag.setModel(new DefaultComboBoxModel(new String[] {"=", ">", "<", ">=", "<="}));
		comboTag.setBounds(342, 277, 107, 26);
		panel_1.add(comboTag);
		
		comboVal = new JTextField();
		comboVal.setBounds(341, 313, 123, 26);
		panel_1.add(comboVal);
		comboVal.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("Movie Tag Value");
		lblNewLabel_7.setBounds(341, 0, 123, 20);
		panel_1.add(lblNewLabel_7);
		
		JButton btnDone = new JButton("Done");
		btnDone.setBounds(503, 312, 115, 29);
		panel_1.add(btnDone);
		
		JButton tagValBtn = new JButton(" Select Tag Values");
		tagValBtn.setBounds(464, 265, 164, 29);
		panel_1.add(tagValBtn);
		
		tagValBtn.addActionListener(new ActionListener()
				{

					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						
						List<String> values = ( ( tag_list.getSelectedValuesList()));
						
					String condition=comboAndOr.getSelectedItem().toString();
					
					    String tag = comboTag.getSelectedItem().toString();    
					    String val = comboVal.getText().toString();
						String sql5	= hw3.getSelectedTagValues(values,condition,tag,val);
					
						String textPaneQ=  hw3.fillTextPane(sql5);
					  textPane.setText("");
					    textPane.setText(textPaneQ);
					}
			
				});
		
		btnDone.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				// Rating and Reviews data fetching
				
				String ratingNotation=(String) comboRating.getSelectedItem();
				String reviewsNotation=(String) comboReviews.getSelectedItem();
				int ratingNum = -1,reviewNum = -1;
				int fromYear = 0;
				int toYear = 0;
				String tagNotation= (String) comboTag.getSelectedItem();;
				int tagValue = 0;
				if(!rating.getText().equals(""))
				{
					 ratingNum=Integer.parseInt(rating.getText());
					
				}
				if(!reviews.getText().equals(""))
				{
					 reviewNum=Integer.parseInt(reviews.getText());
					
					
				}
				if(!fromyear.getText().equals(""))
				{ 
					fromYear = Integer.parseInt(fromyear.getText().toString());
				}
				
				if((!to_year.getText().equals("")))
				{
					toYear = Integer.parseInt(to_year.getText().toString());
				}
				
				if(!comboVal.getText().equals(""))
				{
					tagNotation= (String) comboTag.getSelectedItem();
					tagValue= Integer.parseInt(comboVal.getText().toString());
				}
				
				String condition="";
				if( comboAndOr.getSelectedItem() == "AND")
				{
					condition = " INTERSECT ";
				}else
					condition = " UNION ";
				
				query_display = hw3.getRating(ratingNotation,ratingNum,reviewsNotation,reviewNum,fromYear,toYear,tagNotation,tagValue, condition);
				              String textPaneQuery = hw3.fillTextPane(query_display);
				              textPane.setText("");
								textPane.setText(textPaneQuery);
				
				try {
					ArrayList<String> tagIDlist = hw3.calculateTag(query_display);
					
					
					tag_list = new JList();
					tag_list.clearSelection();
					tag_list.setModel(new AbstractListModel() {
						String[] values =(String[]) tagIDlist.toArray(new String[tagIDlist.size()]);
						public int getSize() {
							return values.length;
						}
						public Object getElementAt(int index) {
							return values[index];
						}
					});
					scroll2.setViewportView(tag_list);
					
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
								
				
			}
		});
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_2.setBounds(31, 375, 590, 267);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		// Execute Query Button Event
		DefaultTableModel model = new DefaultTableModel(new String[] {"Title", "Genre", "Year", "Country", "Locations", "Avg Rating", "Avg Reviews"},0);
		JTable table = new JTable(model);
		scrollPane = new JScrollPane();
		scrollPane.setBounds(35, 45, 498, 206);
		 panel_3 = new JPanel();
			panel_3.setBorder(new LineBorder(new Color(0, 0, 0)));
			panel_3.setBounds(807, 375, 548, 267);
			contentPane.add(panel_3);
			panel_3.setLayout(null);
			
			JLabel lblResult = new JLabel("Result");
			lblResult.setBounds(259, 16, 69, 20);
			panel_3.add(lblResult);
		panel_3.add(scrollPane);
		scrollPane.setViewportView(table);
		
		JButton executeQ = new JButton("Execute Query");
		executeQ.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				model.setRowCount(0);
				String query = textPane.getText().toString();
				ArrayList<Display_Result> arr=	hw3.displayResult(query);
			
			
			String resultSet = "";
			
			
			Object rowData[] = new Object[7];
			
			
			for(int i = 0 ; i < arr.size();i++)
			{
			
				rowData[0] = arr.get(i).title;
				rowData[1] = arr.get(i).genre;
				rowData[2] = arr.get(i).year;
				rowData[3] = arr.get(i).country;
				rowData[4] = arr.get(i).locations;
				rowData[5] = arr.get(i).avgRTAllCriticsRating;
				rowData[6] = arr.get(i).avgRTAllCriticsReviews;
				
//				resultSet  = resultSet + arr.get(i).getTitle() +"\t"+arr.get(i).getGenre()+
//						"\t"+arr.get(i).getYear()+"\t"+arr.get(i).getCountry()+"\t"+arr.get(i).getLocations()+
//						"\t"+arr.get(i).getAvgRTAllCriticsRating()+"\t"+arr.get(i).getAvgRTAllCriticsReviews()+"\n";
				model.addRow(rowData);
			}
			
			
			
			}
		});
		executeQ.setBounds(185, 201, 201, 29);
		panel_2.add(executeQ);
		JScrollPane scroll = new JScrollPane (JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroll.setBounds(10, 10, 580, 180);
		panel_2.add(scroll);
		
		 textPane = new JTextPane();
		scroll.setViewportView(textPane);
		contentPane.setVisible (true);
		
		
		
		
		
		
		
		comboAndOr.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				list_genres.clearSelection();
				
				list_Countries.setListData(new String[0]);
				
				list_locations.setListData(new String[0]);
				
			}
		});
		
	}
}
