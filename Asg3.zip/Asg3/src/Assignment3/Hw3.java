package Assignment3;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import Asg3.dbconnector;

public class Hw3 {
	Connection  connection = null; 
	Statement stmt = null;
	String genreValue ;
	  ArrayList<String> genre = new ArrayList<String>();
	  static String sql4;
	  static String sql5; 
	  static String sql6; // Tag Value
	  static String sql7; // tag weight
	  static String sql8; // except Tag weight
	  static String sqlAllColumn;
	static  ArrayList<Integer>movieID = new ArrayList<Integer>();
	Hw3()
	{
		connection =  dbconnector.getConnection();
	}
	
	public ArrayList<String> getGenres() throws SQLException
	{
		String sql =  "Select distinct Genre from movie_genres";
		stmt = connection.createStatement();
		ResultSet rs1 = stmt.executeQuery(sql);
		 while (rs1.next())
		 {
			 genreValue= rs1.getString("GENRE");
			 genre.add(genreValue);
		 }
		 
		 return genre;
		 		
	}
	
	public ArrayList<String> getCountries(List<String> genres , String condition)
	{
		ArrayList<String> countries = new ArrayList<String>();
		String operation = "";
		int count = 0;
		if (condition.equals("AND"))
		{
			condition="INTERSECT";
		}else
			condition = "UNION";
	
		for(String genre : genres){
		count++;
		if(count == 1)
		operation = "(select movieid from movie_GENRES WHERE GENRE = " + "'"+genre+"'"+ ")";
		else
		operation = operation + " " +condition + "(select movieid from movie_GENRES WHERE GENRE = " + "'"+genre+"'"+ ")";
		}
		String sql = "Select distinct country from MOVIE_COUNTRies where movieID IN (" + operation + " )";
		
		sql4 = operation;
		
		System.out.println(sql);
		Statement stmt = null;
		try {
		stmt = connection.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		while(rs.next()){
		countries.add(rs.getString(1));
		}
		stmt.close();
		} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		return countries;
		
		
	}
	
	public ArrayList<String> getLocations(List<String> countries,List<String> genres , String condition)
	{
		ArrayList<String> locations = new ArrayList<String>();
		String operation = "";
		String operation1 = "";
		int count = 0;
		int cnt = 0;
		if(condition.equals("AND"))
		{
			condition="INTERSECT";
		}
		else
			condition="UNION";
		for(String genre : genres){
		count++;
		if(count == 1)
		operation = "Select movieID from movie_genres where genre = '"+genre+"'";
		else
		operation = operation +" "+ condition + " Select movieID from movie_genres where genre = '"+genre+"'";
		}
		
		
		
		for(String country : countries){
			cnt++;
			if(cnt == 1)
			operation1 = "Select movieID from MOVIE_COUNTRIES where country = '"+country+"'";
			else
			operation1 = operation1 +" "+ condition + " Select movieID from MOVIE_COUNTRIES where country = '"+country+"'";
			}
		
		 if(cnt!=0 && count!=0)
		{sql4 = "(" +operation+")" + " INTERSECT "+ "("+operation1+")";}
		 else
			 if(count!=0 && cnt==0)
			 {sql4 = "(" +operation+")" ;}
			 else if (cnt!=0 && count==0)
			 {sql4 = "(" +operation1 + ")" ;}
		
		
		 
		 String sql3 = "Select distinct location1 from movie_locations where movieid in ("+ sql4 +")";
		
		
		Statement stmt = null;
		try {
		stmt = connection.createStatement();
		ResultSet rs = stmt.executeQuery(sql3);
		while(rs.next()){
			locations.add(rs.getString(1));
		}
		stmt.close();
		} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		
		try {
			stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery(sql4);
			while(rs.next()){
				movieID.add(rs.getInt(1));
			}
			stmt.close();
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
		
		return locations;
	
	}
	
	// After all Column get All movie id
	public void getColumnQuery(List<String> values , String condition)
	{
		String operation = "";
		int count=0;
		if(condition.equals("AND"))
		{
			condition="INTERSECT";
		}
		else
			condition="UNION";
		
		for(String location : values){
			count++;
			if(count == 1)
			operation = "Select movieID from movie_locations where location1 = '"+location+"'";
			else
			operation = operation +" "+ condition + " Select movieID from movie_locations where location1 = '"+location+"'";
			}
		if(count!=0)
		{sql4 = "("+operation+ ")" + " INTERSECT " + sql4;}
		
		
	}

	public String getRating(String ratingnotation, int ratingVal ,String reviewsNotation , int reviewsVal,int fromYear, int toYear,String tagNotation, int tagValue,String condition)
	{
		
		String operation = "";
		String operation1 = "";
		String sql_rating_rating = "";
		String sql_rating_reviews = "";
		String sql_rating_fromYear = "";
		String sql_rating_toYear = "";
		String sql_rating_tagValue = "";
		String Sql_display = "";
		
		
		String sql_final="";
		int count = 0;
		int cnt = 0;
		

		
		if(ratingVal>-1)
		{ sql_rating_rating = "(SELECT ID FROM MOVIES WHERE RTALLCRITICSRATING "+
							ratingnotation + ratingVal +")";
		
//		if(!sql_rating_rating.equals(""))
//		{sql_final = sql_final + sql_rating_rating;}
  	}
		
			if( reviewsVal>-1)
			{ sql_rating_reviews = "(SELECT ID FROM MOVIES WHERE RTALLCRITICSNUMREVIEWS "+
								reviewsNotation + reviewsVal +")";
			
//				if(!sql_rating_reviews.equals(""))
//				{ if(!sql_final.equals(""))
//				{
//					sql_final = sql_final + "INTERSECT " + sql_rating_reviews;
//				}else
//					sql_final = sql_final + sql_rating_reviews;
//				
//				}
			}
			if((!sql_rating_rating.equals(""))&&(!sql_rating_reviews.equals("")))
			{
				sql_final = "("+sql_rating_rating + condition + sql_rating_reviews+")";
			}else if((sql_rating_rating.equals(""))&&(!sql_rating_reviews.equals("")))
			{
				sql_final = sql_rating_reviews;
			}else if((!sql_rating_rating.equals(""))&&(sql_rating_reviews.equals("")))
			{
				sql_final = sql_rating_rating;
			}
				
			
			if(fromYear!=0)
			{
				sql_rating_fromYear = "(SELECT ID FROM MOVIES WHERE YEAR >= "+
						fromYear  +")";
			
				if(!sql_rating_fromYear.equals(""))
				{ if(!sql_final.equals(""))
				{
					sql_final = sql_final + "INTERSECT " + sql_rating_fromYear;
				}else
					sql_final = sql_final + sql_rating_fromYear;
				
				}
			
			}
			
			if(toYear!=0)
			{
				sql_rating_toYear = "(SELECT ID FROM MOVIES WHERE YEAR <= "+
						toYear  +")";
				
				
				if(!sql_rating_toYear.equals(""))
				{ if(!sql_final.equals(""))
				{
					sql_final = sql_final + "INTERSECT " + sql_rating_toYear;
				}else
					sql_final = sql_final + sql_rating_toYear;
				
				}
				
			}
			sql5="";
			sql8="";
			sql8=sql_final;
			sql7="";
			if(tagValue!=0)
			{
				sql_rating_tagValue = "(SELECT movieid FROM MOVIE_tags WHERE tagweight "+
						tagNotation  +  tagValue+")";
				sql7=sql_rating_tagValue;
				
//				{ if(!sql_final.equals(""))
//				{
//					sql5 = sql8 + "INTERSECT " + sql7;
//				}else
//					sql5 = sql_final + sql7;
//				
//				}
				
			}	
				
			
			
//			if((!sql_final.equals(""))&&(!sql4.equals("")))
//				{
//				sql5 ="";
//				sql5 = sql4 + "INTERSECT" + sql_final;
//				}
//			else if (sql_final.equals(""))
//					{sql5=sql4;}
//			
			if(!sql4.equals(""))
			{
				if((!sql8.equals(""))&&(!sql7.equals("")))
				{
					sql5=sql4 + " INTERSECT " + sql8 + " INTERSECT " + sql7;
				}else if ((!sql8.equals("")) && (sql7.equals("")) )
						{
							sql5 = sql4 + " INTERSECT " + sql8;
						}
				else if ((sql8.equals("")) && (!sql7.equals("")) )
				{
					sql5 = sql4 + " INTERSECT " + sql7;
				}else
					sql5 =sql4;
			}else
				if((!sql8.equals(""))&&(!sql7.equals("")))
				{
					sql5 = sql8 + " INTERSECT "+ sql7;
				}else if ((!sql8.equals("")) && (sql7.equals("")) )
				{
					sql5 =   sql8;
				}
				else if ((sql8.equals("")) && (!sql7.equals("")) )
				{
					sql5 =  sql7;
				}
			
					return sql5;
			
	}
	
	public ArrayList<String> calculateTag(String query_sql) throws SQLException
	{
		ArrayList<String> tagidList = new ArrayList<>();
		String tagSQL = "Select tagid from movie_tags where movieid IN (" + query_sql +" )";
		String tagValueSQL = null;
		String tagValue;
		
		 
		 
			 tagValueSQL = "Select distinct value from tags where id in (" + tagSQL + ")" ;
			
		    stmt = connection.createStatement();
			ResultSet rs1 = stmt.executeQuery(tagValueSQL);
			 while (rs1.next())
			 {
				 tagValue= rs1.getString("value");
				 tagidList.add(tagValue);
			 }
		 
		 return tagidList;
		
		
	}
	
	public String getSelectedTagValues(List<String> values,String condition,String tag,String val)
	{
		int count=0;
		String sql="";
		if (condition.equals("OR"))
		{
			condition="UNION";
		}
		else
			condition="INTERSECT";
		String operation = null;
		for(String str : values){
			count++;
			if(count == 1)
			operation ="select id from tags where value = '" + str+"'";
			else
			operation = operation +" "+ condition + " select id from tags where value ='" +str + "'";
			}
		if (!operation.equals(""))
			
		{	if(!val.equals(""))
			
			{ sql = "(Select movieid from movie_tags where tagweight" + tag +" " +val +" AND" +" tagid in (" + operation +"))";
		
			}else
			 {sql = "Select movieid from movie_tags where tagid in (" + operation +")";}
				
		if(!sql8.equals(""))
		{
			sql6 = sql4 +" INTERSECT " + sql8 +" INTERSECT "+sql;
		}
		else
			
		sql6 = sql4 +" INTERSECT "+sql;
			
		}
		
		return sql6;
		
	}
	public String fillTextPane(String query_display)
	{
		ArrayList<Display_Result> result = new ArrayList<>(); 
		String sqlFinal = 
				"select distinct m.title, mg.genre, m.year, mc.country, ml.locations, "
				+"m.rtAllCriticsRating, m.rtTopCriticsRating, m.rtAudienceRating,"
				+ "m.rtAllCriticsNumReviews, m.rtTopCriticsNumReviews, m.rtAudienceNumRatings "
				+ "from movies m,movie_genres mg,movie_countries mc,"
				+ "(select movieID,"
				   +"ltrim(max(sys_connect_by_path"
				     +" (location1, ',' )), ',')"
				      + "locations "
				 +"from (select distinct t.location1, t.movieID, row_number() over "
				          +"(partition by movieID "
				           +"order by location1) rn "
				        +"from (select distinct location1, movieID FROM MOVIE_LOCATIONS) t "
				         +")"
				 +"start with rn = 1 "
				 +"connect by prior rn = rn-1 "
				 +"and prior movieID = movieID "
				 +" group by movieID "
				 +" order by movieID) ml "
				+ "where m.id = mg.movieID and m.id = mc.movieID "
				+ "and m.id = ml.movieID "
				+ "and m.id IN ("+
				
//				"select distinct M1.title, G1.genre, M1.year, C1.country, "+
//				"L1.location1, ROUND((M1.RTALLCRITICSRATING + M1.RTTOPCRITICSRATING" + 
//				" + M1.RTAUDIENCERATING) / 3, 2) , Round((M1.RTALLCRITICSNUMREVIEWS +" + 
//				"M1.RTTOPCRITICSNUMREVIEWS  + M1.RTAUDIENCENUMRATINGS) / 3, 2) from movies M1, "+
//				"movie_genres G1, movie_countries C1,"+
//				"movie_locations L1 where G1.movieid = M1.id and L1.movieid = M1.id"+ 
//				" and C1.movieid=M1.id and M1.id IN ("+

				query_display+")";
		
		System.out.println("SQLFINAL"+sqlFinal);
				return sqlFinal;
	}
		public ArrayList<Display_Result> displayResult(String query_display)
		{
			ArrayList<Display_Result> result = new ArrayList<>(); 

					Statement stmt = null;
					try {
					stmt = connection.createStatement();
					ResultSet rs = stmt.executeQuery(query_display);
					while(rs.next()){
					double avgRating = (rs.getDouble(6) + rs.getDouble(7) + rs.getDouble(8))/3;
					 DecimalFormat df = new DecimalFormat("#.00");
					    String angleFormated = df.format(avgRating);
					
					double avgReviews = (rs.getDouble(9) + rs.getDouble(10) + rs.getDouble(11))/3;
					 DecimalFormat df1 = new DecimalFormat("#.00");
					    String angleFormated1 = df.format(avgReviews);
					
					
					Display_Result fr = new Display_Result(rs.getString(1),rs.getString(2), rs.getInt(3), 
					        rs.getString(4),rs.getString(5), angleFormated, angleFormated1);
//					Display_Result fr = new Display_Result(rs.getString(1),rs.getString(2), rs.getInt(3), 
//					        rs.getString(4),rs.getString(5), rs.getString(6), rs.getString(7));
					result.add(fr);
					}
					stmt.close();
					} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					}
					//
					return result;
		}
		
		
	
	
	
}
